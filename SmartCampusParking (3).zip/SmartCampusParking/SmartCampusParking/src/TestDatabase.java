import dao.UserDao;

import java.util.List;

public class TestDatabase {

    public static void main(String[] args) {

        UserDao userDAO = new UserDao();

        System.out.println("===== USER DATABASE TEST =====");

        List<String[]> users = userDAO.getAllUsers();

        if (users.isEmpty()) {
            System.out.println("No users found.");
        } else {

            for (String[] user : users) {

                System.out.println(
                        "ID: " + user[0] +
                                " | Name: " + user[1] +
                                " | Type: " + user[2] +
                                " | Department: " + user[3] +
                                " | Phone: " + user[4] +
                                " | Email: " + user[5] +
                                " | Status: " + user[6]
                );
            }
        }

        System.out.println("==============================");
    }
}
