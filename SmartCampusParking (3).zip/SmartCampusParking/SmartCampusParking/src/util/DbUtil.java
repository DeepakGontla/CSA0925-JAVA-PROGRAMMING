package util;

import db.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;

public class DbUtil {
    public static Connection getConnection() throws SQLException {
        return DatabaseConnection.getConnection();
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.out.println("Error while closing database connection.");
            }
        }
    }

}
