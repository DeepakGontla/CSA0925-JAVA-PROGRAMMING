package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import  db.DatabaseConnection;

public class DatabaseConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/smart_campus_parking";

    private static final String USER =
            "root";

    private static final String PASSWORD =
            "Imthiaz@2007";
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    public static void main(String[] args) {
        try {
            Connection connection = getConnection();

            if (connection != null) {
                System.out.println("Database connected successfully!");
            }
            connection.close();
        } catch (SQLException e) {
            System.out.println("Database connection failed!");
            e.printStackTrace();
        }
    }
}