package ui;

import db.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class UsersFrame extends JFrame {

    private JTextField nameField;
    private JComboBox<String> typeComboBox;
    private JTextField departmentField;
    private JTextField phoneField;
    private JTextField emailField;
    private JTextField searchField;

    private JTable userTable;
    private DefaultTableModel tableModel;

    private int selectedUserId = -1;

    public UsersFrame() {

        setTitle("Smart Campus Parking - User Management");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createUI();
        loadUsers();
    }

    // =========================================================
    // CREATE USER INTERFACE
    // =========================================================

    private void createUI() {

        setLayout(new BorderLayout(0, 0));

        // =====================================================
        // TITLE
        // =====================================================

        JLabel title = new JLabel(
                "USER MANAGEMENT",
                SwingConstants.CENTER
        );

        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setForeground(new Color(35, 55, 75));

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        20, 10, 15, 10
                )
        );

        add(title, BorderLayout.NORTH);

        // =====================================================
        // MAIN PANEL
        // =====================================================

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        5, 18, 18, 18
                )
        );

        // =====================================================
        // FORM PANEL
        // =====================================================

        JPanel formPanel = new JPanel(
                new GridBagLayout()
        );

        formPanel.setBorder(
                BorderFactory.createTitledBorder(
                        BorderFactory.createLineBorder(
                                new Color(150, 175, 200)
                        ),
                        "User Details"
                )
        );

        GridBagConstraints gbc =
                new GridBagConstraints();

        gbc.insets =
                new Insets(7, 10, 7, 10);

        gbc.fill =
                GridBagConstraints.HORIZONTAL;

        gbc.weightx = 0;

        // -----------------------------------------------------
        // FULL NAME
        // -----------------------------------------------------

        gbc.gridx = 0;
        gbc.gridy = 0;

        JLabel nameLabel =
                new JLabel("Full Name:");

        nameLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        formPanel.add(nameLabel, gbc);

        nameField = new JTextField();
        nameField.setPreferredSize(
                new Dimension(300, 32)
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(nameField, gbc);

        // -----------------------------------------------------
        // USER TYPE
        // -----------------------------------------------------

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0;

        JLabel typeLabel =
                new JLabel("User Type:");

        typeLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        formPanel.add(typeLabel, gbc);

        typeComboBox =
                new JComboBox<>(
                        new String[]{
                                "STUDENT",
                                "FACULTY",
                                "STAFF",
                                "VISITOR"
                        }
                );

        typeComboBox.setPreferredSize(
                new Dimension(300, 32)
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(typeComboBox, gbc);

        // -----------------------------------------------------
        // DEPARTMENT
        // -----------------------------------------------------

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0;

        JLabel departmentLabel =
                new JLabel("Department:");

        departmentLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        formPanel.add(departmentLabel, gbc);

        departmentField = new JTextField();
        departmentField.setPreferredSize(
                new Dimension(300, 32)
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(departmentField, gbc);

        // -----------------------------------------------------
        // PHONE
        // -----------------------------------------------------

        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0;

        JLabel phoneLabel =
                new JLabel("Phone:");

        phoneLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        formPanel.add(phoneLabel, gbc);

        phoneField = new JTextField();
        phoneField.setPreferredSize(
                new Dimension(300, 32)
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(phoneField, gbc);

        // -----------------------------------------------------
        // EMAIL
        // -----------------------------------------------------

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0;

        JLabel emailLabel =
                new JLabel("Email:");

        emailLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        formPanel.add(emailLabel, gbc);

        emailField = new JTextField();
        emailField.setPreferredSize(
                new Dimension(300, 32)
        );

        gbc.gridx = 1;
        gbc.weightx = 1;

        formPanel.add(emailField, gbc);

        // =====================================================
        // BUTTON PANEL
        // =====================================================

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                15,
                                8
                        )
                );

        JButton addButton =
                new JButton("ADD USER");

        JButton updateButton =
                new JButton("UPDATE");

        JButton deleteButton =
                new JButton("DELETE");

        JButton clearButton =
                new JButton("CLEAR");

        Dimension buttonSize =
                new Dimension(120, 38);

        addButton.setPreferredSize(buttonSize);
        updateButton.setPreferredSize(buttonSize);
        deleteButton.setPreferredSize(buttonSize);
        clearButton.setPreferredSize(buttonSize);

        addButton.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        updateButton.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        deleteButton.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        clearButton.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        addButton.addActionListener(
                e -> addUser()
        );

        updateButton.addActionListener(
                e -> updateUser()
        );

        deleteButton.addActionListener(
                e -> deleteUser()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        // =====================================================
        // TOP SECTION
        // =====================================================

        JPanel topSection =
                new JPanel(new BorderLayout(0, 5));

        topSection.add(
                formPanel,
                BorderLayout.CENTER
        );

        topSection.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        // =====================================================
        // SEARCH PANEL
        // =====================================================

        JPanel searchPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.LEFT,
                                10,
                                8
                        )
                );

        searchPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Search"
                )
        );

        JLabel searchLabel =
                new JLabel("Search User:");

        searchLabel.setFont(
                new Font("Arial", Font.BOLD, 14)
        );

        searchField =
                new JTextField(28);

        searchField.setPreferredSize(
                new Dimension(280, 32)
        );

        JButton searchButton =
                new JButton("SEARCH");

        JButton refreshButton =
                new JButton("REFRESH");

        searchButton.setPreferredSize(
                new Dimension(110, 32)
        );

        refreshButton.setPreferredSize(
                new Dimension(110, 32)
        );

        searchButton.addActionListener(
                e -> searchUsers()
        );

        refreshButton.addActionListener(
                e -> {
                    searchField.setText("");
                    loadUsers();
                }
        );

        searchPanel.add(searchLabel);
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(refreshButton);

        // =====================================================
        // TABLE
        // =====================================================

        String[] columns = {
                "ID",
                "Name",
                "Type",
                "Department",
                "Phone",
                "Email",
                "Status"
        };

        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };

        userTable =
                new JTable(tableModel);

        userTable.setRowHeight(28);

        userTable.setFont(
                new Font("Arial", Font.PLAIN, 13)
        );

        userTable.getTableHeader().setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        userTable.getTableHeader().setPreferredSize(
                new Dimension(0, 32)
        );

        userTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        userTable.setAutoResizeMode(
                JTable.AUTO_RESIZE_ALL_COLUMNS
        );

        userTable.getSelectionModel()
                .addListSelectionListener(
                        e -> selectUser()
                );

        JScrollPane scrollPane =
                new JScrollPane(userTable);

        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Registered Users"
                )
        );

        // =====================================================
        // CENTER CONTENT
        // =====================================================

        JPanel contentPanel =
                new JPanel(new BorderLayout(0, 8));

        contentPanel.add(
                searchPanel,
                BorderLayout.NORTH
        );

        contentPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        // =====================================================
        // ADD EVERYTHING
        // =====================================================

        mainPanel.add(
                topSection,
                BorderLayout.NORTH
        );

        mainPanel.add(
                contentPanel,
                BorderLayout.CENTER
        );

        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }

    // =========================================================
    // LOAD USERS
    // =========================================================

    private void loadUsers() {

        tableModel.setRowCount(0);

        String sql =
                "SELECT user_id, full_name, user_type, " +
                        "department, phone, email, status " +
                        "FROM users ORDER BY user_id";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            while (result.next()) {

                tableModel.addRow(
                        new Object[]{
                                result.getInt("user_id"),
                                result.getString("full_name"),
                                result.getString("user_type"),
                                result.getString("department"),
                                result.getString("phone"),
                                result.getString("email"),
                                result.getString("status")
                        }
                );
            }

        } catch (SQLException e) {

            showError(
                    "Unable to load users.",
                    e
            );
        }
    }

    // =========================================================
    // ADD USER
    // =========================================================

    private void addUser() {

        if (!validateForm()) {
            return;
        }

        String sql =
                "INSERT INTO users " +
                        "(full_name, user_type, department, phone, email) " +
                        "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    nameField.getText().trim()
            );

            statement.setString(
                    2,
                    typeComboBox.getSelectedItem().toString()
            );

            statement.setString(
                    3,
                    departmentField.getText().trim()
            );

            statement.setString(
                    4,
                    phoneField.getText().trim()
            );

            statement.setString(
                    5,
                    emailField.getText().trim()
            );

            statement.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "User added successfully!"
            );

            clearForm();
            loadUsers();

        } catch (SQLException e) {

            showError(
                    "Unable to add user.",
                    e
            );
        }
    }

    // =========================================================
    // UPDATE USER
    // =========================================================

    private void updateUser() {

        if (selectedUserId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a user from the table first."
            );

            return;
        }

        if (!validateForm()) {
            return;
        }

        String sql =
                "UPDATE users SET " +
                        "full_name = ?, " +
                        "user_type = ?, " +
                        "department = ?, " +
                        "phone = ?, " +
                        "email = ? " +
                        "WHERE user_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setString(
                    1,
                    nameField.getText().trim()
            );

            statement.setString(
                    2,
                    typeComboBox.getSelectedItem().toString()
            );

            statement.setString(
                    3,
                    departmentField.getText().trim()
            );

            statement.setString(
                    4,
                    phoneField.getText().trim()
            );

            statement.setString(
                    5,
                    emailField.getText().trim()
            );

            statement.setInt(
                    6,
                    selectedUserId
            );

            statement.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "User updated successfully!"
            );

            clearForm();
            loadUsers();

        } catch (SQLException e) {

            showError(
                    "Unable to update user.",
                    e
            );
        }
    }

    // =========================================================
    // DELETE USER
    // =========================================================

    private void deleteUser() {

        if (selectedUserId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a user from the table first."
            );

            return;
        }

        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this user?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        String sql =
                "DELETE FROM users WHERE user_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(
                    1,
                    selectedUserId
            );

            statement.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "User deleted successfully!"
            );

            clearForm();
            loadUsers();

        } catch (SQLException e) {

            showError(
                    "Unable to delete user.\n" +
                            "The user may be referenced by another table.",
                    e
            );
        }
    }

    // =========================================================
    // SEARCH USERS
    // =========================================================

    private void searchUsers() {

        String keyword =
                searchField.getText().trim();

        if (keyword.isEmpty()) {

            loadUsers();
            return;
        }

        tableModel.setRowCount(0);

        String sql =
                "SELECT user_id, full_name, user_type, " +
                        "department, phone, email, status " +
                        "FROM users " +
                        "WHERE full_name LIKE ? " +
                        "OR user_type LIKE ? " +
                        "OR department LIKE ? " +
                        "OR phone LIKE ? " +
                        "OR email LIKE ? " +
                        "ORDER BY user_id";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            String searchPattern =
                    "%" + keyword + "%";

            for (int i = 1; i <= 5; i++) {
                statement.setString(
                        i,
                        searchPattern
                );
            }

            ResultSet result =
                    statement.executeQuery();

            while (result.next()) {

                tableModel.addRow(
                        new Object[]{
                                result.getInt("user_id"),
                                result.getString("full_name"),
                                result.getString("user_type"),
                                result.getString("department"),
                                result.getString("phone"),
                                result.getString("email"),
                                result.getString("status")
                        }
                );
            }

            result.close();

        } catch (SQLException e) {

            showError(
                    "Unable to search users.",
                    e
            );
        }
    }

    // =========================================================
    // SELECT USER FROM TABLE
    // =========================================================

    private void selectUser() {

        int row =
                userTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        selectedUserId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(row, 0)
                                .toString()
                );

        nameField.setText(
                tableModel
                        .getValueAt(row, 1)
                        .toString()
        );

        typeComboBox.setSelectedItem(
                tableModel
                        .getValueAt(row, 2)
                        .toString()
        );

        Object department =
                tableModel.getValueAt(row, 3);

        departmentField.setText(
                department == null
                        ? ""
                        : department.toString()
        );

        phoneField.setText(
                tableModel
                        .getValueAt(row, 4)
                        .toString()
        );

        emailField.setText(
                tableModel
                        .getValueAt(row, 5)
                        .toString()
        );
    }

    // =========================================================
    // VALIDATE FORM
    // =========================================================

    private boolean validateForm() {

        if (nameField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the full name."
            );

            return false;
        }

        if (phoneField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the phone number."
            );

            return false;
        }

        if (emailField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter the email."
            );

            return false;
        }

        return true;
    }

    private void clearForm() {

        selectedUserId = -1;

        nameField.setText("");
        departmentField.setText("");
        phoneField.setText("");
        emailField.setText("");

        typeComboBox.setSelectedIndex(0);

        userTable.clearSelection();
    }

    private void showError(
            String message,
            SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                message +
                        "\n\nDatabase Error:\n" +
                        e.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}