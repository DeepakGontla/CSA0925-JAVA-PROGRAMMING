package ui;

import dao.PaymentDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;

public class PaymentsFrame extends JFrame {

    private JTextField sessionIdField;
    private JTextField amountField;
    private JComboBox<String> methodComboBox;
    private JComboBox<String> statusComboBox;
    private JTextField transactionField;

    private JTable paymentTable;
    private DefaultTableModel tableModel;

    private int selectedPaymentId = -1;

    private final PaymentDao paymentDao;

    public PaymentsFrame() {

        paymentDao = new PaymentDao();

        setTitle("Smart Campus Parking - Payment Management");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createUI();
        loadPayments();
    }


    private void createUI() {

        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel(
                "PAYMENT MANAGEMENT",
                SwingConstants.CENTER
        );

        title.setFont(
                new Font("Arial", Font.BOLD, 25)
        );

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 10, 10, 10
                )
        );

        add(title, BorderLayout.NORTH);


        JPanel mainPanel =
                new JPanel(new BorderLayout(10, 10));

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 15, 15, 15
                )
        );


        // ================= FORM =================

        JPanel formPanel =
                new JPanel(
                        new GridLayout(5, 2, 10, 10)
                );

        formPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Payment Details"
                )
        );


        sessionIdField = new JTextField();
        amountField = new JTextField();

        methodComboBox =
                new JComboBox<>(
                        new String[]{
                                "CASH",
                                "UPI",
                                "CARD"
                        }
                );

        statusComboBox =
                new JComboBox<>(
                        new String[]{
                                "PENDING",
                                "SUCCESS",
                                "FAILED",
                                "REFUNDED"
                        }
                );

        transactionField = new JTextField();


        formPanel.add(new JLabel("Session ID:"));
        formPanel.add(sessionIdField);

        formPanel.add(new JLabel("Amount:"));
        formPanel.add(amountField);

        formPanel.add(new JLabel("Payment Method:"));
        formPanel.add(methodComboBox);

        formPanel.add(new JLabel("Payment Status:"));
        formPanel.add(statusComboBox);

        formPanel.add(new JLabel("Transaction Reference:"));
        formPanel.add(transactionField);


        // ================= BUTTONS =================

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                10
                        )
                );

        JButton addButton =
                new JButton("ADD");

        JButton updateButton =
                new JButton("UPDATE");

        JButton deleteButton =
                new JButton("DELETE");

        JButton clearButton =
                new JButton("CLEAR");


        addButton.addActionListener(
                e -> addPayment()
        );

        updateButton.addActionListener(
                e -> updatePayment()
        );

        deleteButton.addActionListener(
                e -> deletePayment()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );


        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);


        JPanel topPanel =
                new JPanel(new BorderLayout());

        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );


        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );


        // ================= TABLE =================

        String[] columns = {
                "Payment ID",
                "Session ID",
                "Amount",
                "Method",
                "Status",
                "Transaction Reference",
                "Payment Time"
        };


        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };


        paymentTable =
                new JTable(tableModel);

        paymentTable.setRowHeight(25);

        paymentTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );


        paymentTable.getSelectionModel()
                .addListSelectionListener(
                        e -> selectPayment()
                );


        JScrollPane scrollPane =
                new JScrollPane(paymentTable);

        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Payment Records"
                )
        );


        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );


        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }


    // ================= LOAD =================

    private void loadPayments() {

        tableModel.setRowCount(0);

        for (Object[] payment :
                paymentDao.getAllPayments()) {

            tableModel.addRow(payment);
        }
    }


    // ================= ADD =================

    private void addPayment() {

        if (!validateForm()) {
            return;
        }

        try {

            int sessionId =
                    Integer.parseInt(
                            sessionIdField
                                    .getText()
                                    .trim()
                    );

            double amount =
                    Double.parseDouble(
                            amountField
                                    .getText()
                                    .trim()
                    );

            String method =
                    methodComboBox
                            .getSelectedItem()
                            .toString();

            String status =
                    statusComboBox
                            .getSelectedItem()
                            .toString();

            String transaction =
                    transactionField
                            .getText()
                            .trim();


            boolean success =
                    paymentDao.addPayment(
                            sessionId,
                            amount,
                            method,
                            status,
                            transaction
                    );


            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Payment added successfully!"
                );

                clearForm();
                loadPayments();

            } else {

                showError(
                        "Unable to add payment."
                );
            }

        } catch (NumberFormatException e) {

            showError(
                    "Session ID and Amount must be valid numbers."
            );
        }
    }


    // ================= UPDATE =================

    private void updatePayment() {

        if (selectedPaymentId == -1) {

            showError(
                    "Please select a payment first."
            );

            return;
        }

        if (!validateForm()) {
            return;
        }

        try {

            int sessionId =
                    Integer.parseInt(
                            sessionIdField
                                    .getText()
                                    .trim()
                    );

            double amount =
                    Double.parseDouble(
                            amountField
                                    .getText()
                                    .trim()
                    );

            String method =
                    methodComboBox
                            .getSelectedItem()
                            .toString();

            String status =
                    statusComboBox
                            .getSelectedItem()
                            .toString();

            String transaction =
                    transactionField
                            .getText()
                            .trim();


            boolean success =
                    paymentDao.updatePayment(
                            selectedPaymentId,
                            sessionId,
                            amount,
                            method,
                            status,
                            transaction
                    );


            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Payment updated successfully!"
                );

                clearForm();
                loadPayments();

            } else {

                showError(
                        "Unable to update payment."
                );
            }

        } catch (NumberFormatException e) {

            showError(
                    "Session ID and Amount must be valid numbers."
            );
        }
    }


    // ================= DELETE =================

    private void deletePayment() {

        if (selectedPaymentId == -1) {

            showError(
                    "Please select a payment first."
            );

            return;
        }


        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this payment?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );


        if (choice != JOptionPane.YES_OPTION) {
            return;
        }


        boolean success =
                paymentDao.deletePayment(
                        selectedPaymentId
                );


        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Payment deleted successfully!"
            );

            clearForm();
            loadPayments();

        } else {

            showError(
                    "Unable to delete payment."
            );
        }
    }


    // ================= SELECT =================

    private void selectPayment() {

        int row =
                paymentTable.getSelectedRow();

        if (row == -1) {
            return;
        }


        selectedPaymentId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(row, 0)
                                .toString()
                );


        sessionIdField.setText(
                tableModel
                        .getValueAt(row, 1)
                        .toString()
        );


        amountField.setText(
                tableModel
                        .getValueAt(row, 2)
                        .toString()
        );


        methodComboBox.setSelectedItem(
                tableModel
                        .getValueAt(row, 3)
                        .toString()
        );


        statusComboBox.setSelectedItem(
                tableModel
                        .getValueAt(row, 4)
                        .toString()
        );


        Object transaction =
                tableModel.getValueAt(row, 5);

        transactionField.setText(
                transaction == null
                        ? ""
                        : transaction.toString()
        );
    }


    // ================= VALIDATE =================

    private boolean validateForm() {

        if (sessionIdField.getText().trim().isEmpty()) {

            showError(
                    "Please enter Session ID."
            );

            return false;
        }


        if (amountField.getText().trim().isEmpty()) {

            showError(
                    "Please enter Amount."
            );

            return false;
        }


        try {

            int sessionId =
                    Integer.parseInt(
                            sessionIdField
                                    .getText()
                                    .trim()
                    );

            double amount =
                    Double.parseDouble(
                            amountField
                                    .getText()
                                    .trim()
                    );


            if (sessionId <= 0) {

                showError(
                        "Session ID must be greater than 0."
                );

                return false;
            }


            if (amount <= 0) {

                showError(
                        "Amount must be greater than 0."
                );

                return false;
            }

        } catch (NumberFormatException e) {

            showError(
                    "Session ID and Amount must be valid numbers."
            );

            return false;
        }


        return true;
    }


    // ================= CLEAR =================

    private void clearForm() {

        selectedPaymentId = -1;

        sessionIdField.setText("");
        amountField.setText("");
        transactionField.setText("");

        methodComboBox.setSelectedIndex(0);
        statusComboBox.setSelectedIndex(0);

        paymentTable.clearSelection();
    }


    private void showError(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}