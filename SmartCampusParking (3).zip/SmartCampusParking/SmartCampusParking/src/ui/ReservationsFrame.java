package ui;

import dao.ReservationDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;

public class ReservationsFrame extends JFrame {

    private JTextField vehicleIdField;
    private JTextField slotIdField;
    private JTextField fromField;
    private JTextField untilField;

    private JComboBox<String> statusBox;

    private JTable table;
    private DefaultTableModel tableModel;

    private int selectedReservationId = -1;

    private final ReservationDao reservationDAO =
            new ReservationDao();

    private final SimpleDateFormat dateFormat =
            new SimpleDateFormat(
                    "yyyy-MM-dd HH:mm:ss"
            );


    public ReservationsFrame() {

        setTitle(
                "Smart Campus Parking - Reservations"
        );

        setSize(1200, 700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        createUI();

        loadReservations();
    }


    private void createUI() {

        setLayout(
                new BorderLayout(
                        10,
                        10
                )
        );


        // =====================================================
        // TITLE
        // =====================================================

        JLabel title =
                new JLabel(
                        "RESERVATION MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26
                )
        );

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        10,
                        10,
                        10
                )
        );

        add(
                title,
                BorderLayout.NORTH
        );


        // =====================================================
        // FORM
        // =====================================================

        JPanel formPanel =
                new JPanel(
                        new GridLayout(
                                5,
                                2,
                                10,
                                10
                        )
                );

        formPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Reservation Details"
                )
        );


        vehicleIdField =
                new JTextField();


        slotIdField =
                new JTextField();


        fromField =
                new JTextField(
                        "2026-08-31 09:00:00"
                );


        untilField =
                new JTextField(
                        "2026-08-31 13:00:00"
                );


        statusBox =
                new JComboBox<>(
                        new String[]{
                                "PENDING",
                                "CONFIRMED",
                                "COMPLETED",
                                "CANCELLED"
                        }
                );


        formPanel.add(
                new JLabel("Vehicle ID:")
        );

        formPanel.add(
                vehicleIdField
        );


        formPanel.add(
                new JLabel("Slot ID:")
        );

        formPanel.add(
                slotIdField
        );


        formPanel.add(
                new JLabel("Reserved From:")
        );

        formPanel.add(
                fromField
        );


        formPanel.add(
                new JLabel("Reserved Until:")
        );

        formPanel.add(
                untilField
        );


        formPanel.add(
                new JLabel("Status:")
        );

        formPanel.add(
                statusBox
        );


        // =====================================================
        // BUTTONS
        // =====================================================

        JButton addButton =
                new JButton("ADD");


        JButton updateButton =
                new JButton("UPDATE");


        JButton deleteButton =
                new JButton("DELETE");


        JButton clearButton =
                new JButton("CLEAR");


        JButton refreshButton =
                new JButton("REFRESH");


        addButton.addActionListener(
                e -> addReservation()
        );


        updateButton.addActionListener(
                e -> updateReservation()
        );


        deleteButton.addActionListener(
                e -> deleteReservation()
        );


        clearButton.addActionListener(
                e -> clearForm()
        );


        refreshButton.addActionListener(
                e -> loadReservations()
        );


        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                10
                        )
                );


        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(refreshButton);


        JPanel topPanel =
                new JPanel(
                        new BorderLayout()
                );


        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );


        topPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );


        // =====================================================
        // TABLE
        // =====================================================

        String[] columns = {

                "Reservation ID",
                "Vehicle ID",
                "Vehicle Number",
                "Slot ID",
                "Slot Number",
                "Reserved From",
                "Reserved Until",
                "Status"

        };


        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };


        table =
                new JTable(tableModel);


        table.setRowHeight(28);


        table.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );


        table.getSelectionModel()
                .addListSelectionListener(
                        e -> selectReservation()
                );


        JScrollPane scrollPane =
                new JScrollPane(table);


        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Reservations"
                )
        );


        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );


        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        15,
                        15,
                        15
                )
        );


        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );


        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );


        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }


    // =========================================================
    // LOAD RESERVATIONS
    // =========================================================

    private void loadReservations() {

        tableModel.setRowCount(0);


        List<Object[]> reservations =
                reservationDAO
                        .getAllReservations();


        for (Object[] reservation :
                reservations) {

            tableModel.addRow(
                    reservation
            );
        }
    }


    // =========================================================
    // ADD
    // =========================================================

    private void addReservation() {

        if (!validateForm()) {
            return;
        }


        try {

            boolean success =
                    reservationDAO.addReservation(

                            Integer.parseInt(
                                    vehicleIdField
                                            .getText()
                                            .trim()
                            ),

                            Integer.parseInt(
                                    slotIdField
                                            .getText()
                                            .trim()
                            ),

                            Timestamp.valueOf(
                                    fromField
                                            .getText()
                                            .trim()
                            ),

                            Timestamp.valueOf(
                                    untilField
                                            .getText()
                                            .trim()
                            ),

                            statusBox
                                    .getSelectedItem()
                                    .toString()
                    );


            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Reservation added successfully!"
                );

                clearForm();

                loadReservations();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Unable to add reservation."
                );
            }

        } catch (Exception e) {

            showError(
                    "Invalid reservation data.",
                    e
            );
        }
    }


    // =========================================================
    // UPDATE
    // =========================================================

    private void updateReservation() {

        if (selectedReservationId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a reservation first."
            );

            return;
        }


        if (!validateForm()) {
            return;
        }


        try {

            boolean success =
                    reservationDAO.updateReservation(

                            selectedReservationId,

                            Integer.parseInt(
                                    vehicleIdField
                                            .getText()
                                            .trim()
                            ),

                            Integer.parseInt(
                                    slotIdField
                                            .getText()
                                            .trim()
                            ),

                            Timestamp.valueOf(
                                    fromField
                                            .getText()
                                            .trim()
                            ),

                            Timestamp.valueOf(
                                    untilField
                                            .getText()
                                            .trim()
                            ),

                            statusBox
                                    .getSelectedItem()
                                    .toString()
                    );


            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Reservation updated successfully!"
                );

                clearForm();

                loadReservations();
            }

        } catch (Exception e) {

            showError(
                    "Invalid reservation data.",
                    e
            );
        }
    }


    // =========================================================
    // DELETE
    // =========================================================

    private void deleteReservation() {

        if (selectedReservationId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a reservation first."
            );

            return;
        }


        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Delete selected reservation?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );


        if (choice != JOptionPane.YES_OPTION) {
            return;
        }


        boolean success =
                reservationDAO
                        .deleteReservation(
                                selectedReservationId
                        );


        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Reservation deleted successfully!"
            );

            clearForm();

            loadReservations();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to delete reservation."
            );
        }
    }


    // =========================================================
    // SELECT
    // =========================================================

    private void selectReservation() {

        int row =
                table.getSelectedRow();


        if (row == -1) {
            return;
        }


        selectedReservationId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(
                                        row,
                                        0
                                )
                                .toString()
                );


        vehicleIdField.setText(
                tableModel
                        .getValueAt(
                                row,
                                1
                        )
                        .toString()
        );


        slotIdField.setText(
                tableModel
                        .getValueAt(
                                row,
                                3
                        )
                        .toString()
        );


        fromField.setText(
                tableModel
                        .getValueAt(
                                row,
                                5
                        )
                        .toString()
        );


        untilField.setText(
                tableModel
                        .getValueAt(
                                row,
                                6
                        )
                        .toString()
        );


        statusBox.setSelectedItem(
                tableModel
                        .getValueAt(
                                row,
                                7
                        )
                        .toString()
        );
    }


    // =========================================================
    // VALIDATION
    // =========================================================

    private boolean validateForm() {

        if (
                vehicleIdField
                        .getText()
                        .trim()
                        .isEmpty()
                        ||
                        slotIdField
                                .getText()
                                .trim()
                                .isEmpty()
        ) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle ID and Slot ID are required."
            );

            return false;
        }


        try {

            Integer.parseInt(
                    vehicleIdField
                            .getText()
                            .trim()
            );


            Integer.parseInt(
                    slotIdField
                            .getText()
                            .trim()
            );


            Timestamp from =
                    Timestamp.valueOf(
                            fromField
                                    .getText()
                                    .trim()
                    );


            Timestamp until =
                    Timestamp.valueOf(
                            untilField
                                    .getText()
                                    .trim()
                    );


            if (!until.after(from)) {

                JOptionPane.showMessageDialog(
                        this,
                        "Reserved Until must be after Reserved From."
                );

                return false;
            }


        } catch (Exception e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Use date format:\n"
                            + "yyyy-MM-dd HH:mm:ss"
            );

            return false;
        }


        return true;
    }


    // =========================================================
    // CLEAR
    // =========================================================

    private void clearForm() {

        selectedReservationId = -1;

        vehicleIdField.setText("");
        slotIdField.setText("");

        fromField.setText(
                "2026-08-31 09:00:00"
        );

        untilField.setText(
                "2026-08-31 13:00:00"
        );

        statusBox.setSelectedIndex(0);

        table.clearSelection();
    }


    // =========================================================
    // ERROR
    // =========================================================

    private void showError(
            String message,
            Exception e) {

        JOptionPane.showMessageDialog(
                this,
                message
                        + "\n\n"
                        + e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}