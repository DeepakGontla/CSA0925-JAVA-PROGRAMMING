package ui;

import dao.ReportDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ReportsFrame extends JFrame {

    private JLabel usersLabel;
    private JLabel vehiclesLabel;
    private JLabel sessionsLabel;
    private JLabel completedLabel;
    private JLabel revenueLabel;
    private JLabel violationsLabel;
    private JLabel finesLabel;

    private JTable sessionTable;
    private JTable violationTable;

    private DefaultTableModel sessionModel;
    private DefaultTableModel violationModel;

    private final ReportDao reportDao;

    public ReportsFrame() {

        reportDao = new ReportDao();

        setTitle("Smart Campus Parking - Reports & Analytics");
        setSize(1300, 750);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createUI();
        loadReportData();
    }

    private void createUI() {

        setLayout(new BorderLayout(10, 10));

        JLabel title = new JLabel(
                "REPORTS & ANALYTICS",
                SwingConstants.CENTER
        );

        title.setFont(
                new Font("Arial", Font.BOLD, 25)
        );

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 10, 10, 10
                )
        );

        add(title, BorderLayout.NORTH);

        JPanel mainPanel =
                new JPanel(new BorderLayout(10, 10));

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 15, 15, 15
                )
        );

        // ================= SUMMARY CARDS =================

        JPanel summaryPanel =
                new JPanel(
                        new GridLayout(2, 4, 10, 10)
                );

        usersLabel = new JLabel(
                "0",
                SwingConstants.CENTER
        );

        vehiclesLabel = new JLabel(
                "0",
                SwingConstants.CENTER
        );

        sessionsLabel = new JLabel(
                "0",
                SwingConstants.CENTER
        );

        completedLabel = new JLabel(
                "0",
                SwingConstants.CENTER
        );

        revenueLabel = new JLabel(
                "₹0.00",
                SwingConstants.CENTER
        );

        violationsLabel = new JLabel(
                "0",
                SwingConstants.CENTER
        );

        finesLabel = new JLabel(
                "₹0.00",
                SwingConstants.CENTER
        );

        summaryPanel.add(
                createCard("TOTAL USERS", usersLabel)
        );

        summaryPanel.add(
                createCard("TOTAL VEHICLES", vehiclesLabel)
        );

        summaryPanel.add(
                createCard("TOTAL SESSIONS", sessionsLabel)
        );

        summaryPanel.add(
                createCard("COMPLETED SESSIONS", completedLabel)
        );

        summaryPanel.add(
                createCard("PARKING REVENUE", revenueLabel)
        );

        summaryPanel.add(
                createCard("TOTAL VIOLATIONS", violationsLabel)
        );

        summaryPanel.add(
                createCard("TOTAL FINES", finesLabel)
        );

        JButton refreshButton =
                new JButton("REFRESH REPORTS");

        refreshButton.setFont(
                new Font("Arial", Font.BOLD, 13)
        );

        refreshButton.addActionListener(
                e -> loadReportData()
        );

        summaryPanel.add(refreshButton);

        mainPanel.add(
                summaryPanel,
                BorderLayout.NORTH
        );

        // ================= REPORT TABS =================

        JTabbedPane tabbedPane =
                new JTabbedPane();

        // ---------- SESSION REPORT ----------

        String[] sessionColumns = {
                "Session ID",
                "Vehicle ID",
                "Slot ID",
                "Reservation ID",
                "Entry Time",
                "Exit Time",
                "Duration (Min)",
                "Status",
                "Amount"
        };

        sessionModel =
                new DefaultTableModel(
                        sessionColumns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };

        sessionTable =
                new JTable(sessionModel);

        sessionTable.setRowHeight(25);
        sessionTable.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
        );

        JScrollPane sessionScrollPane =
                new JScrollPane(sessionTable);

        tabbedPane.addTab(
                "Parking Session Report",
                sessionScrollPane
        );

        // ---------- VIOLATION REPORT ----------

        String[] violationColumns = {
                "Violation ID",
                "Vehicle ID",
                "Session ID",
                "Violation Type",
                "Description",
                "Fine Amount",
                "Violation Time",
                "Status"
        };

        violationModel =
                new DefaultTableModel(
                        violationColumns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };

        violationTable =
                new JTable(violationModel);

        violationTable.setRowHeight(25);
        violationTable.setAutoResizeMode(
                JTable.AUTO_RESIZE_OFF
        );

        JScrollPane violationScrollPane =
                new JScrollPane(violationTable);

        tabbedPane.addTab(
                "Violation Report",
                violationScrollPane
        );

        mainPanel.add(
                tabbedPane,
                BorderLayout.CENTER
        );

        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }

    private JPanel createCard(
            String title,
            JLabel valueLabel) {

        JPanel panel =
                new JPanel(new BorderLayout());

        panel.setBorder(
                BorderFactory.createLineBorder(
                        Color.GRAY,
                        1
                )
        );

        JLabel titleLabel =
                new JLabel(
                        title,
                        SwingConstants.CENTER
                );

        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        12
                )
        );

        valueLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        24
                )
        );

        panel.add(
                titleLabel,
                BorderLayout.NORTH
        );

        panel.add(
                valueLabel,
                BorderLayout.CENTER
        );

        return panel;
    }

    // ================= LOAD REPORT DATA =================

    private void loadReportData() {

        usersLabel.setText(
                String.valueOf(
                        reportDao.getTotalUsers()
                )
        );

        vehiclesLabel.setText(
                String.valueOf(
                        reportDao.getTotalVehicles()
                )
        );

        sessionsLabel.setText(
                String.valueOf(
                        reportDao.getTotalSessions()
                )
        );

        completedLabel.setText(
                String.valueOf(
                        reportDao.getCompletedSessions()
                )
        );

        revenueLabel.setText(
                String.format(
                        "₹%.2f",
                        reportDao.getTotalRevenue()
                )
        );

        violationsLabel.setText(
                String.valueOf(
                        reportDao.getTotalViolations()
                )
        );

        finesLabel.setText(
                String.format(
                        "₹%.2f",
                        reportDao.getTotalFines()
                )
        );

        loadSessionReport();
        loadViolationReport();
    }

    // ================= SESSION REPORT =================

    private void loadSessionReport() {

        sessionModel.setRowCount(0);

        List<Object[]> sessions =
                reportDao.getSessionReport();

        for (Object[] session : sessions) {

            sessionModel.addRow(session);
        }
    }

    // ================= VIOLATION REPORT =================

    private void loadViolationReport() {

        violationModel.setRowCount(0);

        List<Object[]> violations =
                reportDao.getViolationReport();

        for (Object[] violation : violations) {

            violationModel.addRow(violation);
        }
    }
}
