package ui;

import dao.DashboardDao;

import javax.swing.*;
import java.awt.*;
import java.util.Map;

public class DashboardFrame extends JFrame {

    // =========================================================
    // DASHBOARD COMPONENTS
    // =========================================================

    private JLabel totalSlotsLabel;
    private JLabel occupiedLabel;
    private JLabel availableLabel;
    private JLabel reservedLabel;

    private JPanel slotsPanel;

    private final DashboardDao dashboardDao;


    // =========================================================
    // CONSTRUCTOR
    // =========================================================

    public DashboardFrame() {

        dashboardDao = new DashboardDao();

        setTitle(
                "Smart Campus Parking & Traffic Management"
        );

        setSize(1200, 750);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.EXIT_ON_CLOSE
        );

        setLayout(
                new BorderLayout()
        );

        createHeader();

        createSidebar();

        createDashboard();

        loadDashboardData();
    }


    // =========================================================
    // HEADER
    // =========================================================

    private void createHeader() {

        JPanel header =
                new JPanel(
                        new BorderLayout()
                );

        header.setPreferredSize(
                new Dimension(1200, 70)
        );

        header.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        15,
                        10,
                        15
                )
        );


        JLabel title =
                new JLabel(
                        "SMART CAMPUS PARKING"
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );


        JLabel admin =
                new JLabel(
                        "Administrator   |   Logout"
                );

        admin.setFont(
                new Font(
                        "Arial",
                        Font.PLAIN,
                        15
                )
        );


        header.add(
                title,
                BorderLayout.WEST
        );

        header.add(
                admin,
                BorderLayout.EAST
        );


        add(
                header,
                BorderLayout.NORTH
        );
    }


    // =========================================================
    // SIDEBAR
    // =========================================================

    private void createSidebar() {

        JPanel sidebar =
                new JPanel();


        sidebar.setPreferredSize(
                new Dimension(220, 680)
        );


        sidebar.setLayout(
                new GridLayout(
                        9,
                        1,
                        5,
                        5
                )
        );


        String[] menuItems = {

                "Dashboard",
                "Users",
                "Vehicles",
                "Parking",
                "Reservations",
                "Entry / Exit",
                "Payments",
                "Violations",
                "Reports"

        };


        for (String item : menuItems) {

            JButton button =
                    createMenuButton(item);

            sidebar.add(button);
        }


        add(
                sidebar,
                BorderLayout.WEST
        );
    }


    // =========================================================
    // MENU BUTTON
    // =========================================================

    private JButton createMenuButton(
            String text) {

        JButton button =
                new JButton(text);


        button.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );


        button.setFocusPainted(false);


        button.setCursor(
                new Cursor(
                        Cursor.HAND_CURSOR
                )
        );


        button.addActionListener(
                e -> handleMenu(text)
        );


        return button;
    }


    // =========================================================
    // DASHBOARD
    // =========================================================

    private void createDashboard() {

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );


        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        20,
                        20,
                        20,
                        20
                )
        );


        // -----------------------------------------------------
        // HEADING
        // -----------------------------------------------------

        JLabel heading =
                new JLabel(
                        "Parking Overview"
                );


        heading.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        22
                )
        );


        mainPanel.add(
                heading,
                BorderLayout.NORTH
        );


        // -----------------------------------------------------
        // CENTER
        // -----------------------------------------------------

        JPanel centerPanel =
                new JPanel(
                        new BorderLayout(
                                15,
                                15
                        )
                );


        // -----------------------------------------------------
        // DASHBOARD CARDS
        // -----------------------------------------------------

        JPanel cardsPanel =
                new JPanel(
                        new GridLayout(
                                1,
                                4,
                                15,
                                15
                        )
                );


        totalSlotsLabel =
                new JLabel(
                        "0",
                        SwingConstants.CENTER
                );


        occupiedLabel =
                new JLabel(
                        "0",
                        SwingConstants.CENTER
                );


        availableLabel =
                new JLabel(
                        "0",
                        SwingConstants.CENTER
                );


        reservedLabel =
                new JLabel(
                        "0",
                        SwingConstants.CENTER
                );


        cardsPanel.add(
                createCard(
                        "TOTAL SLOTS",
                        totalSlotsLabel
                )
        );


        cardsPanel.add(
                createCard(
                        "OCCUPIED",
                        occupiedLabel
                )
        );


        cardsPanel.add(
                createCard(
                        "AVAILABLE",
                        availableLabel
                )
        );


        cardsPanel.add(
                createCard(
                        "RESERVED",
                        reservedLabel
                )
        );


        centerPanel.add(
                cardsPanel,
                BorderLayout.NORTH
        );


        // -----------------------------------------------------
        // SLOT PANEL
        // -----------------------------------------------------

        slotsPanel =
                new JPanel(
                        new GridLayout(
                                0,
                                5,
                                10,
                                10
                        )
                );


        JPanel parkingPanel =
                new JPanel(
                        new BorderLayout()
                );


        parkingPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Live Parking Slot Status"
                )
        );


        parkingPanel.add(
                slotsPanel,
                BorderLayout.CENTER
        );


        centerPanel.add(
                parkingPanel,
                BorderLayout.CENTER
        );


        mainPanel.add(
                centerPanel,
                BorderLayout.CENTER
        );


        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }


    // =========================================================
    // DASHBOARD CARD
    // =========================================================

    private JPanel createCard(
            String title,
            JLabel valueLabel) {

        JPanel card =
                new JPanel(
                        new BorderLayout()
                );


        card.setBorder(
                BorderFactory.createLineBorder(
                        Color.GRAY,
                        1
                )
        );


        JLabel titleLabel =
                new JLabel(
                        title,
                        SwingConstants.CENTER
                );


        titleLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        13
                )
        );


        valueLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        30
                )
        );


        card.add(
                titleLabel,
                BorderLayout.NORTH
        );


        card.add(
                valueLabel,
                BorderLayout.CENTER
        );


        return card;
    }


    // =========================================================
    // LOAD DASHBOARD DATA
    // =========================================================

    private void loadDashboardData() {

        try {

            int total =
                    dashboardDao.getTotalSlots();


            int occupied =
                    dashboardDao.getOccupiedSlots();


            int available =
                    dashboardDao.getAvailableSlots();


            int reserved =
                    dashboardDao.getReservedSlots();


            totalSlotsLabel.setText(
                    String.valueOf(total)
            );


            occupiedLabel.setText(
                    String.valueOf(occupied)
            );


            availableLabel.setText(
                    String.valueOf(available)
            );


            reservedLabel.setText(
                    String.valueOf(reserved)
            );


            loadSlotStatuses();

        } catch (Exception e) {

            showError(
                    "Unable to load dashboard data.",
                    e
            );
        }
    }


    // =========================================================
    // LOAD SLOT STATUS
    // =========================================================

    private void loadSlotStatuses() {

        slotsPanel.removeAll();


        Map<String, String> slotStatuses =
                dashboardDao.getSlotStatuses();


        for (
                Map.Entry<String, String> entry :
                slotStatuses.entrySet()
        ) {

            String slotNumber =
                    entry.getKey();


            String status =
                    entry.getValue();


            JButton slotButton =
                    new JButton(
                            "<html><center>"
                                    + slotNumber
                                    + "<br>"
                                    + status
                                    + "</center></html>"
                    );


            slotButton.setFont(
                    new Font(
                            "Arial",
                            Font.BOLD,
                            13
                    )
            );


            setSlotColor(
                    slotButton,
                    status
            );


            slotButton.addActionListener(
                    e ->
                            showSlotDetails(
                                    slotNumber,
                                    status
                            )
            );


            slotsPanel.add(
                    slotButton
            );
        }


        slotsPanel.revalidate();

        slotsPanel.repaint();
    }


    // =========================================================
    // SLOT COLOR
    // =========================================================

    private void setSlotColor(
            JButton button,
            String status) {

        if (status == null) {

            button.setBackground(
                    Color.LIGHT_GRAY
            );

            button.setOpaque(true);

            return;
        }


        switch (status.toUpperCase()) {

            case "AVAILABLE":

                button.setBackground(
                        Color.GREEN
                );

                break;


            case "OCCUPIED":

                button.setBackground(
                        Color.RED
                );

                break;


            case "RESERVED":

                button.setBackground(
                        Color.YELLOW
                );

                break;


            default:

                button.setBackground(
                        Color.LIGHT_GRAY
                );

                break;
        }


        button.setOpaque(true);
    }


    // =========================================================
    // SLOT DETAILS
    // =========================================================

    private void showSlotDetails(
            String slot,
            String status) {

        JOptionPane.showMessageDialog(
                this,

                "Parking Slot : "
                        + slot
                        + "\nCurrent Status : "
                        + status,

                "Slot Information",

                JOptionPane.INFORMATION_MESSAGE
        );
    }


    // =========================================================
    // MENU HANDLER
    // =========================================================

    private void handleMenu(
            String menu) {


        // -----------------------------------------------------
        // DASHBOARD
        // -----------------------------------------------------

        if (menu.equals("Dashboard")) {

            loadDashboardData();

            return;
        }


        // -----------------------------------------------------
        // USERS
        // -----------------------------------------------------

        if (menu.equals("Users")) {

            openUsers();

            return;
        }


        // -----------------------------------------------------
        // VEHICLES
        // -----------------------------------------------------

        if (menu.equals("Vehicles")) {

            openVehicles();

            return;
        }


        // -----------------------------------------------------
        // PARKING
        // -----------------------------------------------------

        if (menu.equals("Parking")) {

            openParking();

            return;
        }


        // -----------------------------------------------------
        // RESERVATIONS
        // -----------------------------------------------------

        if (menu.equals("Reservations")) {

            openModule(
                    "ReservationsFrame",
                    "Reservations"
            );

            return;
        }


        // -----------------------------------------------------
        // ENTRY / EXIT
        // -----------------------------------------------------

        if (menu.equals("Entry / Exit")) {

            openModule(
                    "EntryExitFrame",
                    "Entry / Exit"
            );

            return;
        }


        // -----------------------------------------------------
        // PAYMENTS
        // -----------------------------------------------------

        if (menu.equals("Payments")) {

            openModule(
                    "PaymentsFrame",
                    "Payments"
            );

            return;
        }


        // -----------------------------------------------------
        // VIOLATIONS
        // -----------------------------------------------------

        if (menu.equals("Violations")) {

            openModule(
                    "ViolationsFrame",
                    "Violations"
            );

            return;
        }


        // -----------------------------------------------------
        // REPORTS
        // -----------------------------------------------------

        if (menu.equals("Reports")) {

            openModule(
                    "ReportsFrame",
                    "Reports"
            );
        }
    }


    // =========================================================
    // OPEN USERS
    // =========================================================

    private void openUsers() {

        UsersFrame usersFrame =
                new UsersFrame();

        usersFrame.setVisible(true);
    }


    // =========================================================
    // OPEN VEHICLES
    // =========================================================

    private void openVehicles() {

        VehiclesFrame vehiclesFrame =
                new VehiclesFrame();

        vehiclesFrame.setVisible(true);
    }


    // =========================================================
    // OPEN PARKING
    // =========================================================

    private void openParking() {

        ParkingFrame parkingFrame =
                new ParkingFrame();

        parkingFrame.setVisible(true);
    }


    // =========================================================
    // OPEN FUTURE MODULE
    // =========================================================

    private void openModule(
            String className,
            String moduleName) {

        try {

            Class<?> frameClass =
                    Class.forName(
                            "ui." + className
                    );


            Object object =
                    frameClass
                            .getDeclaredConstructor()
                            .newInstance();


            if (object instanceof JFrame) {

                JFrame frame =
                        (JFrame) object;

                frame.setVisible(true);

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        moduleName
                                + " module is not a JFrame."
                );
            }

        } catch (ClassNotFoundException e) {

            JOptionPane.showMessageDialog(
                    this,

                    moduleName
                            + " module is not created yet.\n\n"
                            + "We will create it next.",

                    moduleName,

                    JOptionPane.INFORMATION_MESSAGE
            );

        } catch (Exception e) {

            showError(
                    "Unable to open "
                            + moduleName
                            + " module.",
                    e
            );
        }
    }


    // =========================================================
    // ERROR MESSAGE
    // =========================================================

    private void showError(
            String message,
            Exception e) {

        JOptionPane.showMessageDialog(

                this,

                message
                        + "\n\n"
                        + e.getMessage(),

                "Database Error",

                JOptionPane.ERROR_MESSAGE
        );
    }
}