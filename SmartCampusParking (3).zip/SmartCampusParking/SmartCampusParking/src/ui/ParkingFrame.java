package ui;

import dao.ParkingDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class ParkingFrame extends JFrame {

    private JTable parkingTable;
    private DefaultTableModel tableModel;

    private JComboBox<String> statusBox;

    private final ParkingDao parkingDAO =
            new ParkingDao();

    private int selectedSlotId = -1;


    public ParkingFrame() {

        setTitle(
                "Smart Campus Parking - Parking Management"
        );

        setSize(1200, 700);

        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        createUI();

        loadSlots();
    }


    private void createUI() {

        setLayout(
                new BorderLayout(10, 10)
        );


        // =====================================================
        // TITLE
        // =====================================================

        JLabel title =
                new JLabel(
                        "PARKING MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        26
                )
        );

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        10,
                        10,
                        10
                )
        );

        add(
                title,
                BorderLayout.NORTH
        );


        // =====================================================
        // CONTROL PANEL
        // =====================================================

        JPanel controlPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                15,
                                10
                        )
                );

        JLabel statusLabel =
                new JLabel(
                        "Change Slot Status:"
                );

        statusLabel.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        14
                )
        );


        statusBox =
                new JComboBox<>(
                        new String[]{
                                "AVAILABLE",
                                "OCCUPIED",
                                "RESERVED"
                        }
                );


        JButton updateButton =
                new JButton(
                        "UPDATE STATUS"
                );


        JButton refreshButton =
                new JButton(
                        "REFRESH"
                );


        updateButton.addActionListener(
                e -> updateStatus()
        );


        refreshButton.addActionListener(
                e -> loadSlots()
        );


        controlPanel.add(statusLabel);

        controlPanel.add(statusBox);

        controlPanel.add(updateButton);

        controlPanel.add(refreshButton);


        // =====================================================
        // TABLE
        // =====================================================

        String[] columns = {

                "Slot ID",
                "Zone",
                "Zone Name",
                "Slot Number",
                "Slot Type",
                "Status",
                "Floor",
                "Active"

        };


        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };


        parkingTable =
                new JTable(
                        tableModel
                );


        parkingTable.setRowHeight(28);


        parkingTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );


        parkingTable
                .getSelectionModel()
                .addListSelectionListener(
                        e -> selectSlot()
                );


        JScrollPane scrollPane =
                new JScrollPane(
                        parkingTable
                );


        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Parking Slots"
                )
        );


        add(
                controlPanel,
                BorderLayout.CENTER
        );


        add(
                scrollPane,
                BorderLayout.SOUTH
        );


        // Fix layout so table gets proper space

        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(
                                10,
                                10
                        )
                );


        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        15,
                        15,
                        15
                )
        );


        mainPanel.add(
                controlPanel,
                BorderLayout.NORTH
        );


        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );


        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }


    // =========================================================
    // LOAD SLOTS
    // =========================================================

    private void loadSlots() {

        tableModel.setRowCount(0);

        List<Object[]> slots =
                parkingDAO.getAllSlots();


        for (Object[] slot : slots) {

            tableModel.addRow(slot);
        }
    }


    // =========================================================
    // SELECT SLOT
    // =========================================================

    private void selectSlot() {

        int row =
                parkingTable.getSelectedRow();


        if (row == -1) {
            return;
        }


        selectedSlotId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(
                                        row,
                                        0
                                )
                                .toString()
                );


        String currentStatus =
                tableModel
                        .getValueAt(
                                row,
                                5
                        )
                        .toString();


        statusBox.setSelectedItem(
                currentStatus
        );
    }


    // =========================================================
    // UPDATE STATUS
    // =========================================================

    private void updateStatus() {

        if (selectedSlotId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select a parking slot first."
            );

            return;
        }


        String status =
                statusBox
                        .getSelectedItem()
                        .toString();


        boolean success =
                parkingDAO.updateSlotStatus(
                        selectedSlotId,
                        status
                );


        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Parking slot status updated!"
            );

            selectedSlotId = -1;

            loadSlots();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to update parking slot."
            );
        }
    }
}