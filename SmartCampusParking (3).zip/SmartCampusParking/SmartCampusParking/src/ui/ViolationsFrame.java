package ui;

import dao.ViolationDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ViolationsFrame extends JFrame {

    private JTextField vehicleIdField;
    private JTextField sessionIdField;
    private JComboBox<String> typeComboBox;
    private JTextField descriptionField;
    private JTextField fineAmountField;
    private JComboBox<String> statusComboBox;

    private JTable violationTable;
    private DefaultTableModel tableModel;

    private int selectedViolationId = -1;

    private final ViolationDao violationDao;

    public ViolationsFrame() {

        violationDao = new ViolationDao();

        setTitle(
                "Smart Campus Parking - Violation Management"
        );

        setSize(1250, 700);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(
                JFrame.DISPOSE_ON_CLOSE
        );

        createUI();
        loadViolations();
    }


    private void createUI() {

        setLayout(
                new BorderLayout(10, 10)
        );


        // ================= TITLE =================

        JLabel title =
                new JLabel(
                        "VIOLATION MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font(
                        "Arial",
                        Font.BOLD,
                        25
                )
        );

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        15,
                        10,
                        10,
                        10
                )
        );

        add(
                title,
                BorderLayout.NORTH
        );


        JPanel mainPanel =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10,
                        15,
                        15,
                        15
                )
        );


        // ================= FORM =================

        JPanel formPanel =
                new JPanel(
                        new GridLayout(
                                6,
                                2,
                                10,
                                10
                        )
                );

        formPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Violation Details"
                )
        );


        vehicleIdField =
                new JTextField();

        sessionIdField =
                new JTextField();


        typeComboBox =
                new JComboBox<>(
                        new String[]{
                                "WRONG_SLOT",
                                "OVERSTAY",
                                "NO_PASS"
                        }
                );


        descriptionField =
                new JTextField();

        fineAmountField =
                new JTextField();


        statusComboBox =
                new JComboBox<>(
                        new String[]{
                                "UNPAID",
                                "PAID",
                                "WAIVED"
                        }
                );


        formPanel.add(
                new JLabel("Vehicle ID:")
        );

        formPanel.add(
                vehicleIdField
        );


        formPanel.add(
                new JLabel("Session ID:")
        );

        formPanel.add(
                sessionIdField
        );


        formPanel.add(
                new JLabel("Violation Type:")
        );

        formPanel.add(
                typeComboBox
        );


        formPanel.add(
                new JLabel("Description:")
        );

        formPanel.add(
                descriptionField
        );


        formPanel.add(
                new JLabel("Fine Amount:")
        );

        formPanel.add(
                fineAmountField
        );


        formPanel.add(
                new JLabel("Status:")
        );

        formPanel.add(
                statusComboBox
        );


        // ================= BUTTONS =================

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                10
                        )
                );


        JButton addButton =
                new JButton("ADD");

        JButton updateButton =
                new JButton("UPDATE");

        JButton deleteButton =
                new JButton("DELETE");

        JButton clearButton =
                new JButton("CLEAR");


        addButton.addActionListener(
                e -> addViolation()
        );

        updateButton.addActionListener(
                e -> updateViolation()
        );

        deleteButton.addActionListener(
                e -> deleteViolation()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );


        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);


        JPanel topPanel =
                new JPanel(
                        new BorderLayout()
                );

        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );


        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );


        // ================= TABLE =================

        String[] columns = {
                "Violation ID",
                "Vehicle ID",
                "Session ID",
                "Violation Type",
                "Description",
                "Fine Amount",
                "Violation Time",
                "Status"
        };


        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };


        violationTable =
                new JTable(
                        tableModel
                );

        violationTable.setRowHeight(25);

        violationTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );


        violationTable
                .getSelectionModel()
                .addListSelectionListener(
                        e -> selectViolation()
                );


        JScrollPane scrollPane =
                new JScrollPane(
                        violationTable
                );

        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Violation Records"
                )
        );


        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );


        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }


    // ================= LOAD =================

    private void loadViolations() {

        tableModel.setRowCount(0);

        for (Object[] violation :
                violationDao.getAllViolations()) {

            tableModel.addRow(
                    violation
            );
        }
    }


    // ================= ADD =================

    private void addViolation() {

        if (!validateForm()) {
            return;
        }

        try {

            int vehicleId =
                    Integer.parseInt(
                            vehicleIdField
                                    .getText()
                                    .trim()
                    );


            Integer sessionId =
                    getSessionId();


            double fineAmount =
                    Double.parseDouble(
                            fineAmountField
                                    .getText()
                                    .trim()
                    );


            String type =
                    typeComboBox
                            .getSelectedItem()
                            .toString();


            String description =
                    descriptionField
                            .getText()
                            .trim();


            String status =
                    statusComboBox
                            .getSelectedItem()
                            .toString();


            boolean success =
                    violationDao.addViolation(
                            vehicleId,
                            sessionId,
                            type,
                            description,
                            fineAmount,
                            status
                    );


            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Violation added successfully!"
                );

                clearForm();
                loadViolations();

            } else {

                showError(
                        "Unable to add violation."
                );
            }

        } catch (NumberFormatException e) {

            showError(
                    "Vehicle ID, Session ID and Fine Amount must be valid numbers."
            );
        }
    }


    // ================= UPDATE =================

    private void updateViolation() {

        if (selectedViolationId == -1) {

            showError(
                    "Please select a violation first."
            );

            return;
        }


        if (!validateForm()) {
            return;
        }


        try {

            int vehicleId =
                    Integer.parseInt(
                            vehicleIdField
                                    .getText()
                                    .trim()
                    );


            Integer sessionId =
                    getSessionId();


            double fineAmount =
                    Double.parseDouble(
                            fineAmountField
                                    .getText()
                                    .trim()
                    );


            String type =
                    typeComboBox
                            .getSelectedItem()
                            .toString();


            String description =
                    descriptionField
                            .getText()
                            .trim();


            String status =
                    statusComboBox
                            .getSelectedItem()
                            .toString();


            boolean success =
                    violationDao.updateViolation(
                            selectedViolationId,
                            vehicleId,
                            sessionId,
                            type,
                            description,
                            fineAmount,
                            status
                    );


            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Violation updated successfully!"
                );

                clearForm();
                loadViolations();

            } else {

                showError(
                        "Unable to update violation."
                );
            }

        } catch (NumberFormatException e) {

            showError(
                    "Vehicle ID, Session ID and Fine Amount must be valid numbers."
            );
        }
    }


    // ================= DELETE =================

    private void deleteViolation() {

        if (selectedViolationId == -1) {

            showError(
                    "Please select a violation first."
            );

            return;
        }


        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Are you sure you want to delete this violation?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );


        if (choice != JOptionPane.YES_OPTION) {
            return;
        }


        boolean success =
                violationDao.deleteViolation(
                        selectedViolationId
                );


        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Violation deleted successfully!"
            );

            clearForm();
            loadViolations();

        } else {

            showError(
                    "Unable to delete violation."
            );
        }
    }


    // ================= SELECT =================

    private void selectViolation() {

        int row =
                violationTable.getSelectedRow();

        if (row == -1) {
            return;
        }


        selectedViolationId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(
                                        row,
                                        0
                                )
                                .toString()
                );


        vehicleIdField.setText(
                tableModel
                        .getValueAt(row, 1)
                        .toString()
        );


        Object sessionId =
                tableModel
                        .getValueAt(row, 2);

        sessionIdField.setText(
                sessionId == null
                        ? ""
                        : sessionId.toString()
        );


        typeComboBox.setSelectedItem(
                tableModel
                        .getValueAt(row, 3)
                        .toString()
        );


        Object description =
                tableModel
                        .getValueAt(row, 4);

        descriptionField.setText(
                description == null
                        ? ""
                        : description.toString()
        );


        Object fine =
                tableModel
                        .getValueAt(row, 5);

        fineAmountField.setText(
                fine == null
                        ? "0"
                        : fine.toString()
        );


        statusComboBox.setSelectedItem(
                tableModel
                        .getValueAt(row, 7)
                        .toString()
        );
    }


    // ================= VALIDATE =================

    private boolean validateForm() {

        if (vehicleIdField
                .getText()
                .trim()
                .isEmpty()) {

            showError(
                    "Please enter Vehicle ID."
            );

            return false;
        }


        if (fineAmountField
                .getText()
                .trim()
                .isEmpty()) {

            showError(
                    "Please enter Fine Amount."
            );

            return false;
        }


        try {

            int vehicleId =
                    Integer.parseInt(
                            vehicleIdField
                                    .getText()
                                    .trim()
                    );


            double fine =
                    Double.parseDouble(
                            fineAmountField
                                    .getText()
                                    .trim()
                    );


            if (vehicleId <= 0) {

                showError(
                        "Vehicle ID must be greater than 0."
                );

                return false;
            }


            if (fine < 0) {

                showError(
                        "Fine Amount cannot be negative."
                );

                return false;
            }


            if (!sessionIdField
                    .getText()
                    .trim()
                    .isEmpty()) {

                int sessionId =
                        Integer.parseInt(
                                sessionIdField
                                        .getText()
                                        .trim()
                        );

                if (sessionId <= 0) {

                    showError(
                            "Session ID must be greater than 0."
                    );

                    return false;
                }
            }

        } catch (NumberFormatException e) {

            showError(
                    "Please enter valid numeric values."
            );

            return false;
        }


        return true;
    }


    // ================= SESSION ID =================

    private Integer getSessionId() {

        String text =
                sessionIdField
                        .getText()
                        .trim();

        if (text.isEmpty()) {
            return null;
        }

        return Integer.parseInt(text);
    }


    // ================= CLEAR =================

    private void clearForm() {

        selectedViolationId = -1;

        vehicleIdField.setText("");
        sessionIdField.setText("");
        descriptionField.setText("");
        fineAmountField.setText("");

        typeComboBox.setSelectedIndex(0);
        statusComboBox.setSelectedIndex(0);

        violationTable.clearSelection();
    }


    private void showError(String message) {

        JOptionPane.showMessageDialog(
                this,
                message,
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}