package ui;

import dao.EntryExitDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EntryExitFrame extends JFrame {

    private JTextField vehicleIdField;
    private JTextField slotIdField;

    private JTable sessionTable;
    private DefaultTableModel tableModel;

    private int selectedSessionId = -1;

    private final EntryExitDao entryExitDAO;

    public EntryExitFrame() {

        entryExitDAO = new EntryExitDao();

        setTitle("Smart Campus Parking - Entry / Exit");
        setSize(1200, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createUI();
        loadSessions();
    }

    // =========================================================
    // CREATE UI
    // =========================================================

    private void createUI() {

        setLayout(new BorderLayout(10, 10));

        // -----------------------------------------------------
        // TITLE
        // -----------------------------------------------------

        JLabel title =
                new JLabel(
                        "ENTRY / EXIT MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font("Arial", Font.BOLD, 24)
        );

        title.setBorder(
                BorderFactory.createEmptyBorder(
                        15, 10, 10, 10
                )
        );

        add(title, BorderLayout.NORTH);

        // -----------------------------------------------------
        // MAIN PANEL
        // -----------------------------------------------------

        JPanel mainPanel =
                new JPanel(new BorderLayout(10, 10));

        mainPanel.setBorder(
                BorderFactory.createEmptyBorder(
                        10, 15, 15, 15
                )
        );

        // -----------------------------------------------------
        // ENTRY FORM
        // -----------------------------------------------------

        JPanel formPanel =
                new JPanel(
                        new GridLayout(2, 2, 10, 10)
                );

        formPanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Vehicle Entry"
                )
        );

        vehicleIdField = new JTextField();

        slotIdField = new JTextField();

        formPanel.add(
                new JLabel("Vehicle ID:")
        );

        formPanel.add(vehicleIdField);

        formPanel.add(
                new JLabel("Slot ID:")
        );

        formPanel.add(slotIdField);

        // -----------------------------------------------------
        // BUTTONS
        // -----------------------------------------------------

        JPanel buttonPanel =
                new JPanel(
                        new FlowLayout(
                                FlowLayout.CENTER,
                                10,
                                10
                        )
                );

        JButton entryButton =
                new JButton("RECORD ENTRY");

        JButton exitButton =
                new JButton("RECORD EXIT");

        JButton refreshButton =
                new JButton("REFRESH");

        JButton clearButton =
                new JButton("CLEAR");

        entryButton.addActionListener(
                e -> recordEntry()
        );

        exitButton.addActionListener(
                e -> recordExit()
        );

        refreshButton.addActionListener(
                e -> loadSessions()
        );

        clearButton.addActionListener(
                e -> clearForm()
        );

        buttonPanel.add(entryButton);
        buttonPanel.add(exitButton);
        buttonPanel.add(refreshButton);
        buttonPanel.add(clearButton);

        JPanel topPanel =
                new JPanel(new BorderLayout());

        topPanel.add(
                formPanel,
                BorderLayout.CENTER
        );

        topPanel.add(
                buttonPanel,
                BorderLayout.SOUTH
        );

        mainPanel.add(
                topPanel,
                BorderLayout.NORTH
        );

        // -----------------------------------------------------
        // TABLE
        // -----------------------------------------------------

        String[] columns = {
                "Session ID",
                "Vehicle ID",
                "Vehicle Number",
                "Slot ID",
                "Slot Number",
                "Entry Time",
                "Exit Time",
                "Duration (Min)",
                "Status",
                "Amount"
        };

        tableModel =
                new DefaultTableModel(
                        columns,
                        0
                ) {

                    @Override
                    public boolean isCellEditable(
                            int row,
                            int column) {

                        return false;
                    }
                };

        sessionTable =
                new JTable(tableModel);

        sessionTable.setRowHeight(28);

        sessionTable.setSelectionMode(
                ListSelectionModel.SINGLE_SELECTION
        );

        sessionTable.getSelectionModel()
                .addListSelectionListener(
                        e -> selectSession()
                );

        JScrollPane scrollPane =
                new JScrollPane(sessionTable);

        scrollPane.setBorder(
                BorderFactory.createTitledBorder(
                        "Parking Entry / Exit Records"
                )
        );

        mainPanel.add(
                scrollPane,
                BorderLayout.CENTER
        );

        add(
                mainPanel,
                BorderLayout.CENTER
        );
    }

    // =========================================================
    // LOAD SESSIONS
    // =========================================================

    private void loadSessions() {

        tableModel.setRowCount(0);

        List<Object[]> sessions =
                entryExitDAO.getAllSessions();

        for (Object[] session : sessions) {

            tableModel.addRow(session);
        }
    }

    // =========================================================
    // RECORD ENTRY
    // =========================================================

    private void recordEntry() {

        String vehicleText =
                vehicleIdField.getText().trim();

        String slotText =
                slotIdField.getText().trim();

        if (vehicleText.isEmpty() ||
                slotText.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter Vehicle ID and Slot ID."
            );

            return;
        }

        try {

            int vehicleId =
                    Integer.parseInt(vehicleText);

            int slotId =
                    Integer.parseInt(slotText);

            boolean success =
                    entryExitDAO.recordEntry(
                            vehicleId,
                            slotId
                    );

            if (success) {

                JOptionPane.showMessageDialog(
                        this,
                        "Vehicle entry recorded successfully!"
                );

                clearForm();
                loadSessions();

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Unable to record vehicle entry.",
                        "Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle ID and Slot ID must be numbers."
            );
        }
    }

    // =========================================================
    // RECORD EXIT
    // =========================================================

    private void recordExit() {

        if (selectedSessionId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select an ACTIVE session from the table."
            );

            return;
        }

        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Record exit for Session ID "
                                + selectedSessionId
                                + "?",
                        "Confirm Exit",
                        JOptionPane.YES_NO_OPTION
                );

        if (choice != JOptionPane.YES_OPTION) {
            return;
        }

        boolean success =
                entryExitDAO.recordExit(
                        selectedSessionId
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle exit recorded successfully!"
            );

            clearForm();
            loadSessions();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to record exit.\n"
                            + "The session may already be completed.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // =========================================================
    // SELECT SESSION
    // =========================================================

    private void selectSession() {

        int row =
                sessionTable.getSelectedRow();

        if (row == -1) {
            return;
        }

        selectedSessionId =
                Integer.parseInt(
                        tableModel
                                .getValueAt(row, 0)
                                .toString()
                );

        vehicleIdField.setText(
                tableModel
                        .getValueAt(row, 1)
                        .toString()
        );

        slotIdField.setText(
                tableModel
                        .getValueAt(row, 3)
                        .toString()
        );
    }

    // =========================================================
    // CLEAR
    // =========================================================

    private void clearForm() {

        selectedSessionId = -1;

        vehicleIdField.setText("");
        slotIdField.setText("");

        sessionTable.clearSelection();
    }
}