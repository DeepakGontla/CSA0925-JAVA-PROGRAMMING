package ui;

import dao.VehicleDao;
import dao.VehicleDao;
import db.DatabaseConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class VehiclesFrame extends JFrame {

    private JTextField userIdField;
    private JTextField numberField;
    private JComboBox<String> typeBox;
    private JTextField modelField;
    private JTextField colorField;

    private JTable table;
    private DefaultTableModel model;

    private int selectedId = -1;

    private final VehicleDao vehicleDAO =
            new VehicleDao();

    public VehiclesFrame() {

        setTitle("Smart Campus Parking - Vehicle Management");
        setSize(1150, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        createUI();
        loadVehicles();
    }

    private void createUI() {

        setLayout(new BorderLayout(10, 10));

        JLabel title =
                new JLabel(
                        "VEHICLE MANAGEMENT",
                        SwingConstants.CENTER
                );

        title.setFont(
                new Font("Arial", Font.BOLD, 26)
        );

        add(title, BorderLayout.NORTH);

        JPanel form =
                new JPanel(
                        new GridLayout(5, 2, 10, 10)
                );

        form.setBorder(
                BorderFactory.createTitledBorder(
                        "Vehicle Details"
                )
        );

        userIdField = new JTextField();
        numberField = new JTextField();

        typeBox =
                new JComboBox<>(
                        new String[]{
                                "CAR",
                                "BIKE",
                                "EV"
                        }
                );

        modelField = new JTextField();
        colorField = new JTextField();

        form.add(new JLabel("User ID:"));
        form.add(userIdField);

        form.add(new JLabel("Vehicle Number:"));
        form.add(numberField);

        form.add(new JLabel("Vehicle Type:"));
        form.add(typeBox);

        form.add(new JLabel("Make / Model:"));
        form.add(modelField);

        form.add(new JLabel("Color:"));
        form.add(colorField);

        JButton add =
                new JButton("ADD");

        JButton update =
                new JButton("UPDATE");

        JButton delete =
                new JButton("DELETE");

        JButton clear =
                new JButton("CLEAR");

        add.addActionListener(e -> addVehicle());
        update.addActionListener(e -> updateVehicle());
        delete.addActionListener(e -> deleteVehicle());
        clear.addActionListener(e -> clearForm());

        JPanel buttons = new JPanel();

        buttons.add(add);
        buttons.add(update);
        buttons.add(delete);
        buttons.add(clear);

        JPanel top =
                new JPanel(
                        new BorderLayout()
                );

        top.add(form, BorderLayout.CENTER);
        top.add(buttons, BorderLayout.SOUTH);

        String[] columns = {
                "ID",
                "User ID",
                "Owner",
                "Vehicle Number",
                "Type",
                "Model",
                "Color",
                "Status"
        };

        model =
                new DefaultTableModel(
                        columns,
                        0
                ) {
                    public boolean isCellEditable(
                            int row,
                            int column) {
                        return false;
                    }
                };

        table = new JTable(model);

        table.setRowHeight(27);

        table.getSelectionModel()
                .addListSelectionListener(
                        e -> selectVehicle()
                );

        JScrollPane scroll =
                new JScrollPane(table);

        JPanel center =
                new JPanel(
                        new BorderLayout(10, 10)
                );

        center.add(
                top,
                BorderLayout.NORTH
        );

        center.add(
                scroll,
                BorderLayout.CENTER
        );

        add(
                center,
                BorderLayout.CENTER
        );
    }

    private void loadVehicles() {

        model.setRowCount(0);

        try (
                Connection con =
                        DatabaseConnection.getConnection()
        ) {

            ResultSet rs =
                    vehicleDAO.getAllVehicles(con);

            while (rs.next()) {

                model.addRow(
                        new Object[]{
                                rs.getInt("vehicle_id"),
                                rs.getInt("user_id"),
                                rs.getString("full_name"),
                                rs.getString("vehicle_number"),
                                rs.getString("vehicle_type"),
                                rs.getString("model"),
                                rs.getString("color"),
                                rs.getString("status")
                        }
                );
            }

            rs.close();

        } catch (SQLException e) {
            showError(e);
        }
    }

    private void addVehicle() {

        if (!validateForm())
            return;

        boolean success =
                vehicleDAO.addVehicle(
                        Integer.parseInt(
                                userIdField.getText().trim()
                        ),
                        numberField.getText().trim(),
                        typeBox.getSelectedItem().toString(),
                        modelField.getText().trim(),
                        colorField.getText().trim()
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle added successfully!"
            );

            clearForm();
            loadVehicles();

        } else {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to add vehicle."
            );
        }
    }

    private void updateVehicle() {

        if (selectedId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Select a vehicle first."
            );

            return;
        }

        if (!validateForm())
            return;

        boolean success =
                vehicleDAO.updateVehicle(
                        selectedId,
                        Integer.parseInt(
                                userIdField.getText().trim()
                        ),
                        numberField.getText().trim(),
                        typeBox.getSelectedItem().toString(),
                        modelField.getText().trim(),
                        colorField.getText().trim()
                );

        if (success) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle updated successfully!"
            );

            clearForm();
            loadVehicles();
        }
    }

    private void deleteVehicle() {

        if (selectedId == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Select a vehicle first."
            );

            return;
        }

        int choice =
                JOptionPane.showConfirmDialog(
                        this,
                        "Delete selected vehicle?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION
                );

        if (choice != JOptionPane.YES_OPTION)
            return;

        if (vehicleDAO.deleteVehicle(selectedId)) {

            JOptionPane.showMessageDialog(
                    this,
                    "Vehicle deleted successfully!"
            );

            clearForm();
            loadVehicles();
        }
    }

    private void selectVehicle() {

        int row =
                table.getSelectedRow();

        if (row == -1)
            return;

        selectedId =
                Integer.parseInt(
                        model.getValueAt(
                                row, 0
                        ).toString()
                );

        userIdField.setText(
                model.getValueAt(
                        row, 1
                ).toString()
        );

        numberField.setText(
                model.getValueAt(
                        row, 3
                ).toString()
        );

        typeBox.setSelectedItem(
                model.getValueAt(
                        row, 4
                ).toString()
        );

        modelField.setText(
                model.getValueAt(
                        row, 5
                ).toString()
        );

        colorField.setText(
                model.getValueAt(
                        row, 6
                ).toString()
        );
    }

    private boolean validateForm() {

        if (userIdField.getText().trim().isEmpty()
                || numberField.getText().trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "User ID and Vehicle Number are required."
            );

            return false;
        }

        try {

            Integer.parseInt(
                    userIdField.getText().trim()
            );

        } catch (NumberFormatException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "User ID must be a number."
            );

            return false;
        }

        return true;
    }

    private void clearForm() {

        selectedId = -1;

        userIdField.setText("");
        numberField.setText("");
        modelField.setText("");
        colorField.setText("");

        typeBox.setSelectedIndex(0);

        table.clearSelection();
    }

    private void showError(SQLException e) {

        JOptionPane.showMessageDialog(
                this,
                "Database Error:\n" +
                        e.getMessage(),
                "Error",
                JOptionPane.ERROR_MESSAGE
        );
    }
}