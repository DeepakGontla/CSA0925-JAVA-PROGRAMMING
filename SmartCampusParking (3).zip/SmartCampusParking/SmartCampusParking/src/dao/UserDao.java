package dao;

import db.DatabaseConnection;
import util.DbUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

    private DatabaseConnection DBUtil;

    // SELECT
    public List<String[]> getAllUsers() {

        List<String[]> users = new ArrayList<>();

        String sql = "SELECT user_id, full_name, user_type, department, phone, email, status " +
                "FROM users ORDER BY user_id";

        try (Connection con = DBUtil.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {

                String[] user = {
                        String.valueOf(rs.getInt("user_id")),
                        rs.getString("full_name"),
                        rs.getString("user_type"),
                        rs.getString("department"),
                        rs.getString("phone"),
                        rs.getString("email"),
                        rs.getString("status")
                };

                users.add(user);
            }

        } catch (SQLException e) {
            System.out.println("Error while fetching users.");
            e.printStackTrace();
        }

        return users;
    }


    // INSERT
    public boolean addUser(
            String fullName,
            String userType,
            String department,
            String phone,
            String email) {

        String sql = "INSERT INTO users " +
                "(full_name, user_type, department, phone, email) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, fullName);
            ps.setString(2, userType);
            ps.setString(3, department);
            ps.setString(4, phone);
            ps.setString(5, email);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error while adding user.");
            e.printStackTrace();
            return false;
        }
    }


    // UPDATE
    public boolean updateUser(
            int userId,
            String fullName,
            String userType,
            String department,
            String phone,
            String email) {

        String sql = "UPDATE users SET " +
                "full_name = ?, " +
                "user_type = ?, " +
                "department = ?, " +
                "phone = ?, " +
                "email = ? " +
                "WHERE user_id = ?";

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, fullName);
            ps.setString(2, userType);
            ps.setString(3, department);
            ps.setString(4, phone);
            ps.setString(5, email);
            ps.setInt(6, userId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error while updating user.");
            e.printStackTrace();
            return false;
        }
    }


    // DELETE
    public boolean deleteUser(int userId) {

        String sql = "DELETE FROM users WHERE user_id = ?";

        try (Connection con = DBUtil.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, userId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error while deleting user.");
            e.printStackTrace();
            return false;
        }
    }
}