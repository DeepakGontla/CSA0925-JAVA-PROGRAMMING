package dao;

import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDao {

    public List<Object[]> getAllPayments() {

        List<Object[]> payments = new ArrayList<>();

        String sql =
                "SELECT payment_id, session_id, amount, " +
                        "payment_method, payment_status, " +
                        "transaction_reference, payment_time " +
                        "FROM payments ORDER BY payment_id";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement = connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                payments.add(new Object[]{
                        result.getInt("payment_id"),
                        result.getInt("session_id"),
                        result.getBigDecimal("amount"),
                        result.getString("payment_method"),
                        result.getString("payment_status"),
                        result.getString("transaction_reference"),
                        result.getTimestamp("payment_time")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return payments;
    }


    public boolean addPayment(
            int sessionId,
            double amount,
            String paymentMethod,
            String paymentStatus,
            String transactionReference) {

        String sql =
                "INSERT INTO payments " +
                        "(session_id, amount, payment_method, " +
                        "payment_status, transaction_reference) " +
                        "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, sessionId);
            statement.setDouble(2, amount);
            statement.setString(3, paymentMethod);
            statement.setString(4, paymentStatus);

            if (transactionReference == null ||
                    transactionReference.trim().isEmpty()) {

                statement.setNull(
                        5,
                        Types.VARCHAR
                );

            } else {

                statement.setString(
                        5,
                        transactionReference.trim()
                );
            }

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean updatePayment(
            int paymentId,
            int sessionId,
            double amount,
            String paymentMethod,
            String paymentStatus,
            String transactionReference) {

        String sql =
                "UPDATE payments SET " +
                        "session_id = ?, " +
                        "amount = ?, " +
                        "payment_method = ?, " +
                        "payment_status = ?, " +
                        "transaction_reference = ? " +
                        "WHERE payment_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, sessionId);
            statement.setDouble(2, amount);
            statement.setString(3, paymentMethod);
            statement.setString(4, paymentStatus);

            if (transactionReference == null ||
                    transactionReference.trim().isEmpty()) {

                statement.setNull(
                        5,
                        Types.VARCHAR
                );

            } else {

                statement.setString(
                        5,
                        transactionReference.trim()
                );
            }

            statement.setInt(6, paymentId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean deletePayment(int paymentId) {

        String sql =
                "DELETE FROM payments WHERE payment_id = ?";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, paymentId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}