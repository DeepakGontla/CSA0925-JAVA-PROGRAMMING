package dao;

import db.DatabaseConnection;

import java.sql.*;

public class VehicleDao {

    public ResultSet getAllVehicles(Connection con) throws SQLException {

        String sql =
                "SELECT v.vehicle_id, v.user_id, u.full_name, " +
                        "v.vehicle_number, v.vehicle_type, v.model, " +
                        "v.color, v.status " +
                        "FROM vehicles v " +
                        "JOIN users u ON v.user_id = u.user_id " +
                        "ORDER BY v.vehicle_id";

        PreparedStatement ps =
                con.prepareStatement(sql);

        return ps.executeQuery();
    }

    public boolean addVehicle(
            int userId,
            String vehicleNumber,
            String vehicleType,
            String model,
            String color) {

        String sql =
                "INSERT INTO vehicles " +
                        "(user_id, vehicle_number, vehicle_type, model, color) " +
                        "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);
            ps.setString(2, vehicleNumber);
            ps.setString(3, vehicleType);
            ps.setString(4, model);
            ps.setString(5, color);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateVehicle(
            int vehicleId,
            int userId,
            String vehicleNumber,
            String vehicleType,
            String model,
            String color) {

        String sql =
                "UPDATE vehicles SET " +
                        "user_id=?, " +
                        "vehicle_number=?, " +
                        "vehicle_type=?, " +
                        "model=?, " +
                        "color=? " +
                        "WHERE vehicle_id=?";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, userId);
            ps.setString(2, vehicleNumber);
            ps.setString(3, vehicleType);
            ps.setString(4, model);
            ps.setString(5, color);
            ps.setInt(6, vehicleId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteVehicle(int vehicleId) {

        String sql =
                "DELETE FROM vehicles WHERE vehicle_id=?";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, vehicleId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}