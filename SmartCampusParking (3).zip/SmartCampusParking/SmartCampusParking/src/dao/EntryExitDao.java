package dao;

import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EntryExitDao {

    // =========================================================
    // GET ALL PARKING SESSIONS
    // =========================================================

    public List<Object[]> getAllSessions() {

        List<Object[]> sessions = new ArrayList<>();

        String sql =
                "SELECT " +
                        "ps.session_id, " +
                        "ps.vehicle_id, " +
                        "v.vehicle_number, " +
                        "ps.slot_id, " +
                        "s.slot_number, " +
                        "ps.entry_time, " +
                        "ps.exit_time, " +
                        "ps.duration_minutes, " +
                        "ps.parking_status, " +
                        "ps.calculated_amount " +
                        "FROM parking_sessions ps " +
                        "JOIN vehicles v ON ps.vehicle_id = v.vehicle_id " +
                        "JOIN parking_slots s ON ps.slot_id = s.slot_id " +
                        "ORDER BY ps.session_id DESC";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            while (result.next()) {

                sessions.add(
                        new Object[]{
                                result.getInt("session_id"),
                                result.getInt("vehicle_id"),
                                result.getString("vehicle_number"),
                                result.getInt("slot_id"),
                                result.getString("slot_number"),
                                result.getTimestamp("entry_time"),
                                result.getTimestamp("exit_time"),
                                result.getObject("duration_minutes"),
                                result.getString("parking_status"),
                                result.getBigDecimal("calculated_amount")
                        }
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return sessions;
    }


    // =========================================================
    // RECORD ENTRY
    // =========================================================

    public boolean recordEntry(
            int vehicleId,
            int slotId) {

        String sql =
                "INSERT INTO parking_sessions " +
                        "(vehicle_id, slot_id, entry_time, parking_status, calculated_amount) " +
                        "VALUES (?, ?, NOW(), 'ACTIVE', 0.00)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, vehicleId);
            statement.setInt(2, slotId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // =========================================================
    // RECORD EXIT
    // =========================================================

    public boolean recordExit(int sessionId) {

        String sql =
                "UPDATE parking_sessions " +
                        "SET exit_time = NOW(), " +
                        "duration_minutes = TIMESTAMPDIFF(MINUTE, entry_time, NOW()), " +
                        "parking_status = 'COMPLETED' " +
                        "WHERE session_id = ? " +
                        "AND parking_status = 'ACTIVE'";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, sessionId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    // =========================================================
    // GET ACTIVE SESSIONS
    // =========================================================

    public List<Object[]> getActiveSessions() {

        List<Object[]> sessions = new ArrayList<>();

        String sql =
                "SELECT " +
                        "ps.session_id, " +
                        "ps.vehicle_id, " +
                        "v.vehicle_number, " +
                        "ps.slot_id, " +
                        "s.slot_number, " +
                        "ps.entry_time, " +
                        "ps.parking_status " +
                        "FROM parking_sessions ps " +
                        "JOIN vehicles v ON ps.vehicle_id = v.vehicle_id " +
                        "JOIN parking_slots s ON ps.slot_id = s.slot_id " +
                        "WHERE ps.parking_status = 'ACTIVE' " +
                        "ORDER BY ps.entry_time";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            while (result.next()) {

                sessions.add(
                        new Object[]{
                                result.getInt("session_id"),
                                result.getInt("vehicle_id"),
                                result.getString("vehicle_number"),
                                result.getInt("slot_id"),
                                result.getString("slot_number"),
                                result.getTimestamp("entry_time"),
                                result.getString("parking_status")
                        }
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return sessions;
    }


    // =========================================================
    // CALCULATE PARKING DURATION
    // =========================================================

    public int getDurationMinutes(int sessionId) {

        String sql =
                "SELECT TIMESTAMPDIFF(" +
                        "MINUTE, entry_time, NOW()" +
                        ") AS duration " +
                        "FROM parking_sessions " +
                        "WHERE session_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, sessionId);

            try (ResultSet result = statement.executeQuery()) {

                if (result.next()) {
                    return result.getInt("duration");
                }
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return 0;
    }
}