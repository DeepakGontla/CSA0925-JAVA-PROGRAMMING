package dao;

import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReservationDao {

    public List<Object[]> getAllReservations() {

        List<Object[]> reservations = new ArrayList<>();

        String sql =
                "SELECT r.reservation_id, " +
                        "r.vehicle_id, " +
                        "v.vehicle_number, " +
                        "r.slot_id, " +
                        "ps.slot_number, " +
                        "r.reserved_from, " +
                        "r.reserved_until, " +
                        "r.reservation_status " +
                        "FROM reservations r " +
                        "JOIN vehicles v ON r.vehicle_id = v.vehicle_id " +
                        "JOIN parking_slots ps ON r.slot_id = ps.slot_id " +
                        "ORDER BY r.reservation_id";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql);

                ResultSet rs =
                        ps.executeQuery()
        ) {

            while (rs.next()) {

                reservations.add(
                        new Object[]{
                                rs.getInt("reservation_id"),
                                rs.getInt("vehicle_id"),
                                rs.getString("vehicle_number"),
                                rs.getInt("slot_id"),
                                rs.getString("slot_number"),
                                rs.getTimestamp("reserved_from"),
                                rs.getTimestamp("reserved_until"),
                                rs.getString("reservation_status")
                        }
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reservations;
    }


    public boolean addReservation(
            int vehicleId,
            int slotId,
            Timestamp reservedFrom,
            Timestamp reservedUntil,
            String status) {

        String sql =
                "INSERT INTO reservations " +
                        "(vehicle_id, slot_id, reserved_from, reserved_until, reservation_status) " +
                        "VALUES (?, ?, ?, ?, ?)";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, vehicleId);
            ps.setInt(2, slotId);
            ps.setTimestamp(3, reservedFrom);
            ps.setTimestamp(4, reservedUntil);
            ps.setString(5, status);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    public boolean updateReservation(
            int reservationId,
            int vehicleId,
            int slotId,
            Timestamp reservedFrom,
            Timestamp reservedUntil,
            String status) {

        String sql =
                "UPDATE reservations SET " +
                        "vehicle_id=?, " +
                        "slot_id=?, " +
                        "reserved_from=?, " +
                        "reserved_until=?, " +
                        "reservation_status=? " +
                        "WHERE reservation_id=?";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, vehicleId);
            ps.setInt(2, slotId);
            ps.setTimestamp(3, reservedFrom);
            ps.setTimestamp(4, reservedUntil);
            ps.setString(5, status);
            ps.setInt(6, reservationId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }


    public boolean deleteReservation(
            int reservationId) {

        String sql =
                "DELETE FROM reservations " +
                        "WHERE reservation_id=?";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setInt(1, reservationId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();

            return false;
        }
    }
}