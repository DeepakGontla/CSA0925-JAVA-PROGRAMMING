package dao;

import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ReportDao {

    public int getTotalUsers() {
        return getCount(
                "SELECT COUNT(*) FROM users"
        );
    }

    public int getTotalVehicles() {
        return getCount(
                "SELECT COUNT(*) FROM vehicles"
        );
    }

    public int getTotalSessions() {
        return getCount(
                "SELECT COUNT(*) FROM parking_sessions"
        );
    }

    public int getCompletedSessions() {
        return getCount(
                "SELECT COUNT(*) FROM parking_sessions " +
                        "WHERE parking_status = 'COMPLETED'"
        );
    }

    public int getTotalViolations() {
        return getCount(
                "SELECT COUNT(*) FROM violations"
        );
    }

    public double getTotalRevenue() {
        return getDouble(
                "SELECT COALESCE(SUM(calculated_amount),0) " +
                        "FROM parking_sessions " +
                        "WHERE parking_status = 'COMPLETED'"
        );
    }

    public double getTotalFines() {
        return getDouble(
                "SELECT COALESCE(SUM(fine_amount),0) " +
                        "FROM violations"
        );
    }

    public List<Object[]> getSessionReport() {

        List<Object[]> list = new ArrayList<>();

        String sql =
                "SELECT session_id, vehicle_id, slot_id, " +
                        "reservation_id, entry_time, exit_time, " +
                        "duration_minutes, parking_status, calculated_amount " +
                        "FROM parking_sessions " +
                        "ORDER BY session_id";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            while (result.next()) {

                list.add(new Object[]{
                        result.getInt("session_id"),
                        result.getInt("vehicle_id"),
                        result.getInt("slot_id"),
                        result.getObject("reservation_id"),
                        result.getTimestamp("entry_time"),
                        result.getTimestamp("exit_time"),
                        result.getObject("duration_minutes"),
                        result.getString("parking_status"),
                        result.getBigDecimal("calculated_amount")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    public List<Object[]> getViolationReport() {

        List<Object[]> list = new ArrayList<>();

        String sql =
                "SELECT violation_id, vehicle_id, session_id, " +
                        "violation_type, description, fine_amount, " +
                        "violation_time, status " +
                        "FROM violations " +
                        "ORDER BY violation_id";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            while (result.next()) {

                list.add(new Object[]{
                        result.getInt("violation_id"),
                        result.getInt("vehicle_id"),
                        result.getObject("session_id"),
                        result.getString("violation_type"),
                        result.getString("description"),
                        result.getBigDecimal("fine_amount"),
                        result.getTimestamp("violation_time"),
                        result.getString("status")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }

    private int getCount(String sql) {

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            if (result.next()) {
                return result.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    private double getDouble(String sql) {

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql);

                ResultSet result =
                        statement.executeQuery()
        ) {

            if (result.next()) {
                return result.getDouble(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0.0;
    }
}