package dao;

import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ViolationDao {

    public List<Object[]> getAllViolations() {

        List<Object[]> violations = new ArrayList<>();

        String sql =
                "SELECT violation_id, vehicle_id, session_id, " +
                        "violation_type, description, fine_amount, " +
                        "violation_time, status " +
                        "FROM violations ORDER BY violation_id";

        try (
                Connection connection = DatabaseConnection.getConnection();
                PreparedStatement statement =
                        connection.prepareStatement(sql);
                ResultSet result = statement.executeQuery()
        ) {

            while (result.next()) {

                Object sessionId =
                        result.getObject("session_id");

                violations.add(new Object[]{
                        result.getInt("violation_id"),
                        result.getInt("vehicle_id"),
                        sessionId,
                        result.getString("violation_type"),
                        result.getString("description"),
                        result.getBigDecimal("fine_amount"),
                        result.getTimestamp("violation_time"),
                        result.getString("status")
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return violations;
    }


    public boolean addViolation(
            int vehicleId,
            Integer sessionId,
            String violationType,
            String description,
            double fineAmount,
            String status) {

        String sql =
                "INSERT INTO violations " +
                        "(vehicle_id, session_id, violation_type, " +
                        "description, fine_amount, status) " +
                        "VALUES (?, ?, ?, ?, ?, ?)";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, vehicleId);

            if (sessionId == null) {
                statement.setNull(2, Types.INTEGER);
            } else {
                statement.setInt(2, sessionId);
            }

            statement.setString(3, violationType);
            statement.setString(4, description);
            statement.setDouble(5, fineAmount);
            statement.setString(6, status);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean updateViolation(
            int violationId,
            int vehicleId,
            Integer sessionId,
            String violationType,
            String description,
            double fineAmount,
            String status) {

        String sql =
                "UPDATE violations SET " +
                        "vehicle_id = ?, " +
                        "session_id = ?, " +
                        "violation_type = ?, " +
                        "description = ?, " +
                        "fine_amount = ?, " +
                        "status = ? " +
                        "WHERE violation_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, vehicleId);

            if (sessionId == null) {
                statement.setNull(2, Types.INTEGER);
            } else {
                statement.setInt(2, sessionId);
            }

            statement.setString(3, violationType);
            statement.setString(4, description);
            statement.setDouble(5, fineAmount);
            statement.setString(6, status);
            statement.setInt(7, violationId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean deleteViolation(int violationId) {

        String sql =
                "DELETE FROM violations WHERE violation_id = ?";

        try (
                Connection connection =
                        DatabaseConnection.getConnection();

                PreparedStatement statement =
                        connection.prepareStatement(sql)
        ) {

            statement.setInt(1, violationId);

            return statement.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
