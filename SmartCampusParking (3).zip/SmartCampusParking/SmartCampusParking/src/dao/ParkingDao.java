package dao;

import db.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ParkingDao {

    public List<Object[]> getAllSlots() {

        List<Object[]> slots = new ArrayList<>();

        String sql =
                "SELECT ps.slot_id, " +
                        "pz.zone_code, " +
                        "pz.zone_name, " +
                        "ps.slot_number, " +
                        "ps.slot_type, " +
                        "ps.status, " +
                        "ps.floor_no, " +
                        "ps.is_active " +
                        "FROM parking_slots ps " +
                        "JOIN parking_zones pz ON ps.zone_id = pz.zone_id " +
                        "ORDER BY ps.slot_id";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql);

                ResultSet rs =
                        ps.executeQuery()
        ) {

            while (rs.next()) {

                slots.add(
                        new Object[]{
                                rs.getInt("slot_id"),
                                rs.getString("zone_code"),
                                rs.getString("zone_name"),
                                rs.getString("slot_number"),
                                rs.getString("slot_type"),
                                rs.getString("status"),
                                rs.getInt("floor_no"),
                                rs.getBoolean("is_active")
                        }
                );
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }

        return slots;
    }


    public boolean updateSlotStatus(
            int slotId,
            String status) {

        String sql =
                "UPDATE parking_slots " +
                        "SET status = ? " +
                        "WHERE slot_id = ?";

        try (
                Connection con =
                        DatabaseConnection.getConnection();

                PreparedStatement ps =
                        con.prepareStatement(sql)
        ) {

            ps.setString(1, status);
            ps.setInt(2, slotId);

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {

            e.printStackTrace();
            return false;
        }
    }
}