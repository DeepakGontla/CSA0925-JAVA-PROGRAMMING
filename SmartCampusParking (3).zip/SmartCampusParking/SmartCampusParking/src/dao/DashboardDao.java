package dao;

import db.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedHashMap;
import java.util.Map;

public class DashboardDao {

    // Get total number of parking slots
    public int getTotalSlots() {

        String sql = "SELECT COUNT(*) FROM parking_slots";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            if (result.next()) {
                return result.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // Get occupied slots
    public int getOccupiedSlots() {

        String sql =
                "SELECT COUNT(*) FROM parking_slots WHERE status = 'OCCUPIED'";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            if (result.next()) {
                return result.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // Get available slots
    public int getAvailableSlots() {

        String sql =
                "SELECT COUNT(*) FROM parking_slots WHERE status = 'AVAILABLE'";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            if (result.next()) {
                return result.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // Get reserved slots
    public int getReservedSlots() {

        String sql =
                "SELECT COUNT(*) FROM parking_slots WHERE status = 'RESERVED'";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            if (result.next()) {
                return result.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0;
    }

    // Get every parking slot and its current status
    public Map<String, String> getSlotStatuses() {

        Map<String, String> slotStatuses = new LinkedHashMap<>();

        String sql =
                "SELECT slot_number, status " +
                        "FROM parking_slots " +
                        "ORDER BY slot_id";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet result = statement.executeQuery()) {

            while (result.next()) {

                String slotNumber =
                        result.getString("slot_number");

                String status =
                        result.getString("status");

                slotStatuses.put(slotNumber, status);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return slotStatuses;
    }
}