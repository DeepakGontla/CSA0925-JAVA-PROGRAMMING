import dao.DashboardDao;

import java.util.Map;

public class DashboardTest {

    public static void main(String[] args) {

        DashboardDao dashboardDAO = new DashboardDao();

        System.out.println("===== DASHBOARD DATABASE TEST =====");

        System.out.println(
                "Total Slots    : " +
                        dashboardDAO.getTotalSlots()
        );

        System.out.println(
                "Occupied Slots : " +
                        dashboardDAO.getOccupiedSlots()
        );

        System.out.println(
                "Available Slots: " +
                        dashboardDAO.getAvailableSlots()
        );

        System.out.println(
                "Reserved Slots : " +
                        dashboardDAO.getReservedSlots()
        );

        System.out.println("\n===== SLOT STATUS =====");

        Map<String, String> slots =
                dashboardDAO.getSlotStatuses();

        for (Map.Entry<String, String> entry :
                slots.entrySet()) {

            System.out.println(
                    entry.getKey() +
                            " -> " +
                            entry.getValue()
            );
        }

        System.out.println(
                "=============================="
        );
    }
}